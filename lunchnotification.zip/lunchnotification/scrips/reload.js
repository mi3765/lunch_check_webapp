function doReloadNoCache() {
    // キャッシュを無視してサーバーからリロード
    window.location.reload();
};